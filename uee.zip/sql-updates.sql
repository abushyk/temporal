-- видалення поля МФО
DELETE FROM inputs_exch WHERE `name` IN ('bank_code1', 'bank_code2', 'bank_code3');

-- зміна типу поля Форма власності на select
UPDATE `inputs_exch` SET `value` = '\"Державна\",\"Приватна\",\"Комунальна\"', `fieldtype` = 3 WHERE `name` = 'company_ownership_form';

-- додавання полів під англ варіант імені із впорядкуванням
UPDATE `inputs_exch` SET `ord` = `ord` + 1 WHERE `ord` > 117;
INSERT INTO `inputs_exch` (`ord`, `name`, `value`, `descr`, `fieldtype`, `parent`, `header`, `mandatory`, `pctwidth`, `note`, `regexp`, `validation_info`) VALUES ('118', 'agent_fullname_eng3', '', '', '1', '', '0', '1', '50', '(англійською мовою)', '', '');

UPDATE `inputs_exch` SET `ord` = `ord` + 1 WHERE `ord` > 96;
INSERT INTO `inputs_exch` (`ord`, `name`, `value`, `descr`, `fieldtype`, `parent`, `header`, `mandatory`, `pctwidth`, `note`, `regexp`, `validation_info`) VALUES ('97', 'agent_fullname_eng1', '', '', '1', '', '0', '1', '50', '(англійською мовою)', '', '');

UPDATE `inputs_exch` SET `ord` = `ord` + 1 WHERE `ord` > 75;
INSERT INTO `inputs_exch` (`ord`, `name`, `value`, `descr`, `fieldtype`, `parent`, `header`, `mandatory`, `pctwidth`, `note`, `regexp`, `validation_info`) VALUES ('76', 'agent_fullname_eng2', '', '', '1', '', '0', '1', '50', '(англійською мовою)', '', '');

